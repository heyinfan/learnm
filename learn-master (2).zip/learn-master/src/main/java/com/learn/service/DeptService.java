package com.learn.service;

import com.learn.pojo.Dept;

import java.util.List;

/**
 * @Author： XO
 * @Description：
 * @Date： 2019/5/13 18:32
 */

public interface DeptService {


    public List<Dept> findAllDept();
}
